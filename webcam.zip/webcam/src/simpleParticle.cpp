#include "simpleParticle.h"

//-----------------------------------------------
simpleParticle::simpleParticle(ofVec2f _loc)
{
    loc = ofVec2f(_loc);
    vel = ofVec2f(0,0);
    accel = ofVec2f(0,0);
    lifespan =  150;

    agingRate = 2;
    radius = 10;
    color = generateHsbColor(loc.x, loc.y);

}
//------------------------------------------------------------------
ofColor simpleParticle::generateHsbColor(int x, int y)
{
    ofColor color = ofColor(ofRandom(255), ofRandom(255), ofRandom(255));
    ofColor newColor = color.fromHsb(ofMap(x, 0, ofGetWidth(), 0, 255), ofMap(y, 0, ofGetHeight(), 0, 255), ofRandom(0,255));
    return newColor;
}
//------------------------------------------------------------------
void simpleParticle::applyForce(ofVec2f f)
{
    accel += f;
}
//------------------------------------------------------------------
void simpleParticle::update()
{
    vel+=accel;
    loc+=vel;
    accel*=0;

    lifespan -= agingRate;
    lifespan = ofClamp(lifespan, 0, 255);

}
//-----------------------------------------------------------------------
bool simpleParticle::isDead()
{
    if (lifespan <= 0) return true;
    else return false;
}
